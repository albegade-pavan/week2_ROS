#!/usr/bin/env python

import time
import rospy
from geometry_msgs.msg import Twist
from std_msgs.msg import Float32
from WEEK2_ROS.srv import rotation_service,rotation_serviceRequest
from WEEK2_ROS.srv import rotation_serviceResponse
import math

v = 0.1



def get_radius(radius):
    radius=radius.data
    handle_Velocity(radius)
    
    
def handle_Velocity(radius):
    rospy.wait_for_service('/compute_ang_vel')
    velocity=rospy.ServiceProxy('/compute_ang_vel',rotation_service)
    vel=rotation_serviceRequest()
    vel.r=radius
    response=rotation_serviceResponse()
    ang_vel=velocity(radius)
            #print(ang_vel)
    print(ang_vel.w)
    print("this is the angular velocity")
    turtle_pub(ang_vel.w)

def turtle_pub(w):
    pub=rospy.Publisher('/cmd_vel',Twist,queue_size=10)
    
    ang_vel=rotation_serviceResponse()
    ang_vel.w=w
    turt_pub(ang_vel.w)
    
def turt_pub(w):
    move=Twist()
    pub=rospy.Publisher('/cmd_vel',Twist,queue_size=10)
    constant=2*math.pi/w
    
    while not rospy.is_shutdown():
        
        move.linear.x=v
        move.angular.z=w
        r=rospy.Rate(5)
        pub.publish(move)
        time.sleep(constant)
        move.linear.x=0
        move.angular.z=0
        
        #pub.publish(move)
        time.sleep(5)
        move.linear.x=v
        move.angular.z=-w
        pub.publish(move)
        time.sleep(constant)
        
        #r.sleep()


if __name__=="__main__":
    rospy.init_node('pub_node')
    sub=rospy.Subscriber('/radius',Float32,get_radius)
    
    rospy.spin()


 