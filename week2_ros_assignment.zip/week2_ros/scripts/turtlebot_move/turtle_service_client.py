#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from std_msgs.msg import Float32
from WEEK2_ROS.srv import rotation_service,rotation_serviceRequest
from WEEK2_ROS.srv import rotation_serviceResponse
v = 0.1


def get_radius(radius):
    radius=radius.data
    handle_Velocity(radius)
    
    
def handle_Velocity(radius):
    rospy.wait_for_service('/compute_ang_vel')
    velocity=rospy.ServiceProxy('/compute_ang_vel',rotation_service)
    vel=rotation_serviceRequest()
    vel.r=radius
    response=rotation_serviceResponse()
    ang_vel=velocity(radius)
            #print(ang_vel)
    print(ang_vel.w)
    print("this is the angular velocity")
    turtle_pub(ang_vel.w)

def turtle_pub(w):
    pub=rospy.Publisher('/cmd_vel',Twist,queue_size=10)
    #rospy.init_node('Pub_turtle')
    ang_vel=rotation_serviceResponse()
    ang_vel.w=w
    move=Twist()
    move.linear.x=v
    move.angular.z=w
    while not rospy.is_shutdown():
        pub.publish(move)
        rate=rospy.Rate(2)
        rate.sleep() 
      

def subscriber_function():
    rospy.init_node('mother_node')
    sub=rospy.Subscriber('/radius',Float32,get_radius)
    rospy.spin() 

    
    



if __name__ == '__main__':
    subscriber_function()
    
    
    
    
    







