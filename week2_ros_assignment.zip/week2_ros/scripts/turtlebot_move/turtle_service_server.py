#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from std_msgs.msg import Float32
from WEEK2_ROS.srv import rotation_service,rotation_serviceRequest
from WEEK2_ROS.srv import rotation_serviceResponse

req=rotation_serviceRequest()
response=rotation_serviceResponse()
v=0.1

rospy.init_node('turtle_server')


def calc_vel(req):
    response.w=v/req.r
    print("angular velocity is calculated")
    print(response.w)
    return response.w
    



service=rospy.Service('compute_ang_vel',rotation_service,calc_vel)
rospy.spin()