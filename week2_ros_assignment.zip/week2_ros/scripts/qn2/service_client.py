#!/usr/bin/env python

import rospy
from WEEK2_ROS.srv import robot_trajectory
from WEEK2_ROS.srv import robot_trajectoryRequest,robot_trajectoryResponse
import matplotlib.pyplot as plt
import numpy as np


def plot_function(xp,yp,thetap,vp,wp):
    rospy.init_node('robot_traj_client')
    rospy.wait_for_service('Plot_points')
    projection_service=rospy.ServiceProxy('Plot_points',robot_trajectory)
    plot=robot_trajectoryRequest()
    plot.x=xp
    plot.y=yp
    plot.theta=thetap
    plot.v=vp

    plot.w=wp
    result=projection_service(plot)
    #print(result.x_final)
    #print(result.y_final)
   
            
        


if __name__ == '__main__':
    plot_function(0.0,0.0,0.0,1.0,0.5)
    
