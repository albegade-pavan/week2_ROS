#!/usr/bin/env python

import rospy
from WEEK2_ROS.srv import robot_trajectory
from WEEK2_ROS.srv import robot_trajectoryRequest,robot_trajectoryResponse
import matplotlib.pyplot as plt
import numpy as np

response=robot_trajectoryResponse()
n=25
time=0.1

def callback(req):
    x_list=[]
    y_list=[]
    
    
    for i in range(0,n):
            response.theta_final = response.theta_final+ time * req.w 
            response.x_final =  response.x_final+req.v * np.cos(response.theta_final) * time 
            response.y_final =  response.y_final+req.v * np.sin(response.theta_final) * time 
            x_list.append(response.x_final)
            y_list.append(response.y_final)
    plt.plot(x_list,y_list,color='red')
    
    plt.grid()
    plt.show()
    return response

    

    

if __name__ == '__main__':
    rospy.init_node('robot_traj_server')
    service=rospy.Service('Plot_points',robot_trajectory,callback)
    rospy.spin()

    

