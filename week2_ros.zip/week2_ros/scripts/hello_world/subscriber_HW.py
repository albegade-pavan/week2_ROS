#!/usr/bin/env python

import rospy
from std_msgs.msg import String

def callback1(msg):
    print(msg)
    pub.publish(msg.data)
    r=rospy.Rate(2)
    r.sleep()


def callback2(msg):
    print(msg)
    pub.publish(msg.data)
    r=rospy.Rate(2)
    r.sleep()

if __name__ == '__main__' :
    rospy.init_node('subscriber_helloworld')
    sub1=rospy.Subscriber('/hello',String,callback1)
    sub2=rospy.Subscriber('/world',String,callback2)
    pub=rospy.Publisher("/helloworld",String,queue_size=10)
    

    rospy.spin()
